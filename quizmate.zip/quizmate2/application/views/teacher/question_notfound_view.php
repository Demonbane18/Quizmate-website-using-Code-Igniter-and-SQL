<tr class='warning'>
	<td colspan='5' class='text-center' style="padding: 0;">
		<div class="callout callout-warning question-notfound" style="margin: 0;">
			<h4>No information or question was found.</h4>
			<p>You can create quizzes immediately by clicking "Add a new problem"</p>
		</div>
	</td>
</tr>