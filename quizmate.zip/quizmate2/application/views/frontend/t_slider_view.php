	<!-- slider -->
	<div id="slider">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="callbacks_container">
						<ul class="rslides pic_slider">
							<li>
								<img src="assets-student/img/slider-home/pic%20(1).jpg" alt="">
								<div class="slider-info">
									<h1>Quizmate
										<br>
										Create quiz.<br>
										Anytime. Anywhere.</h1>
								</div>
							</li>
							<li>
								<img src="assets-student/img/slider-home/pic%20(2).jpg" alt="">
								<div class="slider-info">
									<h1 class="black">A library of quizzes
										<br>
										to test your knowledge.<br>
										Are you up for the test?</h1>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- slider close -->