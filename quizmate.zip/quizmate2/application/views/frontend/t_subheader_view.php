	<div id="subheader">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1><?php echo ($title!=''?$title:$this->misc->getClassName());?></h1>
					<span><?php echo ($subtitle!=''?$subtitle:'');?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="clearfix"></div>