			</div>
		</div>
	</div>
	<!-- End body -->

	<!-- Begin Footer -->

	<!--<script src="vendor/js/jquery.min.js"></script>-->
	<script src="vendor/js/bootstrap.min.js"></script>
	<script src="vendor/js/bootswatch.js"></script>
	<!--<script src="vendor/js/messenger.min.js"></script>-->
	
	<!-- End Footer -->
</body>
</html>