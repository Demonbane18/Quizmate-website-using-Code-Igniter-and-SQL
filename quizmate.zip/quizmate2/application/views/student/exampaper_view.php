<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 exampaper">
				<div class="inner">
					<div class="row">
						<div class="col-md-12">
							<?php
								echo $this->fullexampaper->createExamPaper();
							?>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="clearfix"></div>