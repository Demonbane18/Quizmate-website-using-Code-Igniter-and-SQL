<!doctype html>
<html lang="en" ng-app="app">
<head>
	<base href="<?php echo base_url(); ?>">
	<meta charset="utf-8">
	<title>Quizmate</title>
	<link rel="stylesheet" href="vendor/css/bootstrap.min.css">
	<link rel="stylesheet" href="vendor/css/messenger.css">
	<link rel="stylesheet" href="vendor/css/messenger-theme-air.css">
	<link rel="stylesheet" href="css/app.css">
	<script src="vendor/js/jquery.min.js"></script>
	<script src="vendor/js/messenger.min.js"></script>
</head>
<body>